-- ******************** 1ª Avaliação – 4º Bimestre ***************************

-- ******************* Instruções para a avaliação. **************************
-- •	Antes de entregar renomeie o arquivo da prova, colocando seu nome;
--      	Ex: Eliton_camargo.sql
-- •	Ao terminar a avaliação chame o professor para recolher o arquivo;

-- ************* Diagrama da base de dados segue em anexo; ********************


-- ************************** Script da base de dados **************************


create database lojaWeb;

use lojaWeb;

create table usuario (
	cpf varchar(14) primary key,
	email varchar(50) not null unique,
	senha varchar(10) not null,
	nome varchar(20) not null,
	sobrenome varchar(50) not null,
	sexo char(1) null,
	data_nasc date not null,
	cep int not null,
	uf char(2) not null,          
	cidade varchar(100) not null,
	bairro varchar(100) not null,
	rua varchar(100) not null,
	numero varchar(10) not null         
)ENGINE=InnoDB;

create table produto (
	codigo int auto_increment primary key,
	descricao varchar(150) not null,
	quant_estoque int null,
	valor double           
)ENGINE=InnoDB;

create table produto_item (
	id_Prod varchar(20) not null,
	fk_produto int not null,
	data_fabric date not null,
	data_validade date null,
	foreign key (fk_produto) references produto(codigo) on delete cascade on update cascade,
	primary key (id_Prod,fk_produto)
)ENGINE=InnoDB;

create table pedido (
	codigo int auto_increment primary key,
	FK_Usuario varchar(14) not null,
	valorPedido  money not null,
	dataPedido date not null,
	statusPedido int not null,
	foreign key(FK_Usuario) references usuario(cpf) on delete cascade on update cascade
)ENGINE=InnoDB;

create table produtos_em_pedido (
	Fk_produto int not null,
	Fk_pedido  int not null,
	quantidade int default 1 not null,
	primary key (Fk_produto,Fk_pedido),
	foreign key (Fk_produto) references produto(codigo) on delete cascade on update cascade,
	foreign key (Fk_pedido ) references pedido (codigo)  on delete cascade on update cascade
)ENGINE=InnoDB;

-- ******************** Exercícios ************************************
-- 1º.	Crie um procedimento para cadastros de usuário.
-- 2º.	Crie um procedimento para alteração de dados de usuário.
-- 3º.	Crie um procedimento para exclusão de usuário.
-- 4º.	Crie um procedimento de consulta de usuário por CPF.
-- 5º.	Crie um procedimento de consulta de usuários por nome.
-- 6º.	Crie um procedimento para cadastro produto.
-- 7º.	Crie um procedimento para excluir produto.
-- 8º.	Crie um procedimento para consultar produtos. 
-- 9º.	Crie um procedimento para cadastrar produto_item.
-- 10º.	Crie um procedimento para excluir produto_item.
-- 11º.	Crie um procedimento para cadastrar pedido
-- 12º.	Crie um procedimento para excluir pedido.
-- 13º.	Crie um procedimento para consultar todos os pedidos.
-- 14º.	Crie um procedimento para excluir todos os pedidos de um usuário.
-- 15º.	Crie um procedimento para adicionar produto em pedido, levando em consideração que se o produto não existir no estoque não poderá ser adicionado ao pedido.
-- 16º.	Crie um procedimento para excluir um produto de um pedido.
